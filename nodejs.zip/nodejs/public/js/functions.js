function alert(msg,type){ var r_msg = '';
    if(msg != null && type!=''){
        if(type == 'success'){
            r_msg = '<span class="alert alert-success">'+msg+'</span>';
        }else if(type == 'danger'){
            r_msg = '<span class="alert alert-danger">'+msg+'</span>';
        }else if(type == 'warning'){
            r_msg = '<span class="alert alert-warning">'+msg+'</span>';
        }else if(type == 'info'){
            r_msg = '<span class="alert alert-info">'+msg+'</span>';
        }
        
    } return r_msg;
}