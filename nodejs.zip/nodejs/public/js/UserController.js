var app = angular.module('nodeJs', []);

app.directive('fileModel', ['$parse', function ($parse) {
    return {
    restrict: 'A',
    link: function(scope, element, attrs) {
        var model = $parse(attrs.fileModel);
        var modelSetter = model.assign;

        element.bind('change', function(){
            scope.$apply(function(){
                modelSetter(scope, element[0].files[0]);
            });
        });
    }
   };
}]);

// We can write our own fileUpload service to reuse it in the controller
app.service('fileUpload', ['$http', function ($http) {
    this.uploadFileToUrl = function(file, uploadUrl, scope_data){
         var fd = new FormData();
         fd.append('sample_file', file);
         
         fd.append("data", JSON.stringify(scope_data));
         
         $http.post(uploadUrl, fd, {
             transformRequest: angular.identity,
             headers: {'Content-Type': undefined,'Process-Data': false}
         })
         .success(function(){
            console.log("Success");
         })
         .error(function(){
            console.log("Error");
         });
     }
 }]);
 

app.controller('UserController',function($scope,$http){
    
    $scope.users = [];
    $http({
            method : 'GET',
            url : '/user_list'
        }).success(function(data){ 
            //console.log(data);
            $scope.users = data;
        });
        
    //$scope.user = {};
    $scope.msg = '';
        
    $scope.createUser = function() {
        
            var file = $scope.user.profile;
            var fd = new FormData();
            fd.append('profile', file);
            
            fd.append("data", JSON.stringify($scope.user));
            
            $http.post('/signup', fd,{
             transformRequest: angular.identity,
             headers: {'Content-Type': undefined,'Process-Data': false}
         })
            .success(function (data, status){
                $("#msg").html(alert(data.msg,data.type));
                //$scope.msg = alert(data.msg,data.type);
                $http({
                    method : 'GET',
                    url : '/user_list'
                }).success(function(data){ 
                    //console.log(data);
                    $scope.users = data;
                });
                $scope.user = [];
                $scope.hideAlert();
            })
            .error(function (data, status) {
                $scope.ResponseDetails = "Data: " + data +
                    "<hr />status: " + status;
            });
        
    }
    
    $scope.updateUser = function() {
        
            var file = $scope.edit.profile;
            var fd = new FormData();
            fd.append('profile', file);            
            fd.append("data", JSON.stringify($scope.edit));
            
            $http.post('/update_user', fd,{
             transformRequest: angular.identity,
             headers: {'Content-Type': undefined,'Process-Data': false}
         })
            .success(function (data, status){
                $("#msg").html(alert(data.msg,data.type));
                $("#editModal").modal('hide');
                $http({
                    method : 'GET',
                    url : '/user_list'
                }).success(function(data){ 
                    //console.log(data);
                    $scope.users = data;
                });
                $scope.hideAlert();
            })
            .error(function (data, status) {
                console.log(data);
            });
        
    }
    
    /* Customize Functions */
    //$scope.user = [];
    
    $scope.editUser = function(id){
        
        $('[ng-submit="createUser()"]').removeAttr('ng-submit').attr('ng-submit','updateUser('+id+')');
        $http.get('/edit?id='+id).success(function(data){
           
            //console.log();
            $scope.edit = data[0];
            $scope.apply;
        }).error(function(){ 
            
        });
    }
    $scope.deleteUser = function(id){
        if(confirm("Are you sure want to delete?")){
        $http.get('/delete?id='+id).success(function(data){
                $("#msg").html(alert(data.msg,data.type));
                $http({
                    method : 'GET',
                    url : '/user_list'
                }).success(function(data){
                    $scope.users = data;
                });
                $scope.hideAlert();
        }).error(function(data){
            console.log(data);
        }); }
    }
    /* User defined functions */
    $scope.getExt = function(filename){ var o = '';
        var imageExt = ['png','jpg','jpeg','gif','bmp'];
        var docExt = ['txt','doc','docx','xls','xlsx','pdf','zip'];
        var ext = filename.split(".").pop();
       
        if(imageExt.indexOf(ext)>-1){
            o = 'image';
        }else if(docExt.indexOf(ext)>-1){
            o = 'document';
        } return o;
    }
    $scope.hideAlert = function(){
        $(".alert").fadeTo(2000, 500).slideUp(500, function(){
            $(".alert").slideUp(500);
        });
        return;
    }
});

