var http = require('http');
var fs = require('fs');
var url = require('url');


var express = require('express');
var fileUpload = require('express-fileupload');
var app = express();
var path = require('path');


app.use("/public", express.static(path.join(__dirname, 'public'))); 

var bodyParser = require('body-parser'); 

app.use(bodyParser.json());

app.use(fileUpload());

// create application/x-www-form-urlencoded parser
var urlencodedParser = bodyParser.urlencoded({ extended: true });


var mysql   = require('mysql');
var db = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : 'root',
  database : 'nodejs'
}); 
 
db.connect(); 

//var connection;


//handleDisconnect();

app.use(express.static('public'));



app.post('/signup', urlencodedParser ,  function (req, res){
            console.log(req.body.data);
            var obj = JSON.parse(req.body.data);
                        
            if (!req.files) { 
                //res.send('No files were uploaded.');
                //return;
            }
            
            var dir = './public/uploads';

            if (!fs.existsSync(dir)){
                fs.mkdirSync(dir);
            }
            var pr = '';
            if (req.files) { 
                    sampleFile = req.files.profile;
                    sampleFile.mv(dir+'/'+req.files.profile.name, function(err){
                        if (err){
                            res.status(500).send(err);
                        }
                        else {
                            //res.send('File uploaded!');
                        }
                    });
                    pr = req.files.profile.name;
            }
                        
            db.query("select * from tbl_users WHERE email='"+obj.email+"'",function (err,result){ 
                  if(result.length == 0){
                        db.query('INSERT INTO tbl_users (`username`,`email`,`profile`) VALUES ("'+obj.username+'","'+obj.email+'","'+pr+'")', function(err, insert) { 
                            response = {
                               msg :  'Registration has been completed !',
                               type:  'success'
                           };
                           res.end(JSON.stringify(response)); 
                   });
                   
              }else{ 
                  response1 = {
                        msg :  'Sorry, This `email` already exist !',
                        type:  'danger'
                    };
                  res.end(JSON.stringify(response1));
              } 
           });  
        //res.end("Singup!");                      
           
});

app.post('/update_user', urlencodedParser ,  function (req, res){
            console.log(req.body.data);
            var obj = JSON.parse(req.body.data);
                        
            var dir = './public/uploads';

            if (!fs.existsSync(dir)){
                fs.mkdirSync(dir);
            }
            var pr = '';
            if (req.files) { 
                    sampleFile = req.files.profile;
                    sampleFile.mv(dir+'/'+req.files.profile.name, function(err){
                        if (err){
                            res.status(500).send(err);
                        }
                        else {
                            //res.send('File uploaded!');
                        }
                    });
                    pr = ',`profile`="'+req.files.profile.name+'"';
            }
            if(obj.user_id!=''){     
                db.query("select * from tbl_users WHERE email='"+obj.email+"'",function (err,result){ 
                      if(result.length <= 1){
                            db.query('UPDATE tbl_users SET `username`="'+obj.username+'",`email`="'+obj.email+'" '+pr+' WHERE user_id='+obj.user_id, function(err, insert) { 
                                response = {
                                   msg :  'User has been updated !',
                                   type:  'success'
                               };
                               res.end(JSON.stringify(response)); 
                       });

                  }else{ 
                      response1 = {
                            msg :  'Sorry, This `email` already exist !',
                            type:  'danger'
                        };
                      res.end(JSON.stringify(response1));
                  } 
               });  
            }
        //res.end("Singup!");                      
           
});

app.get('/edit', function (req, res){
        //res.end("Welcome to edit");
       if(req.query.id){
            db.query("select * from tbl_users WHERE user_id="+req.query.id,function (err,result){                 
                     res.end(JSON.stringify(result));             
            }); 
        }else{
            res.end('');
        }
});

app.get('/delete',function (req,res){
        if(req.query.id){
            db.query("DELETE from tbl_users WHERE user_id="+req.query.id,function (err,result){                 
                     response = {
                                   msg :  'User has been delete !',
                                   type:  'success'
                               };
                     res.end(JSON.stringify(response));           
            }); 
        }else{
            res.end('');
        }
})

app.get('/signup', function (req, res){
        res.sendFile( __dirname + "/template/" + "signup.html" );
});

app.get('/user_list', function (req, res){
    db.query("select * from tbl_users",function (err,result){                 
              res.end(JSON.stringify(result));            
     }); 
});

/* File Upload */

var server = app.listen(8081, function () {
  var host = server.address().address;
  var port = server.address().port;
  console.log("Example app listening at http://%s:%s", host, port); 

})