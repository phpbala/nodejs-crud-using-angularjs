var http = require('http');
var fs = require('fs');
var url = require('url');

var express = require('express');
app = express() 
var path = require('path'); 
app.use(express.static('public'));
app.use("/public", express.static(path.join(__dirname, 'public'))); 
var bodyParser = require('body-parser');
var urlencodedParser = bodyParser.urlencoded({ extended: true });

// Retrieve 
var db = require('mongodb').MongoClient;

// Connect to the db
//db.connect("mongodb://localhost:27017/exampleDb", function(err, db) {
//  if(err) { return console.log(err); }
//
//  //db.createCollection('tbl_employee', {strict:true}, function(err, collection) {});
//    
//  //var collection = db.collection('tbl_employee');
//    
//});

app.post('/signup', urlencodedParser ,  function (req, res){ 
            response = {
                name:  req.body.name,
                email    : req.body.email,
                password    : req.body.password
            };     
            db.connect("mongodb://localhost:27017/exampleDb", function(err, db) {
                if(err) { return console.log(err); }
                var collection = db.collection('tbl_employee');
                 collection.insert(response);
              });
               
           console.log(response);
           res.end(JSON.stringify(response)); //             
})

app.get('/users', function(req,res){
    res.sendFile( __dirname + "/" + "users.html" );
});

app.get('/signup', function (req, res){
        res.sendFile( __dirname + "/" + "signup.html" );
});

app.listen(8081); // Super PORT
