var http = require('http');
var fs = require('fs');
var url = require('url');

var express = require('express');
app = express() 
var path = require('path'); 
app.use(express.static('public'));
app.use("/public", express.static(path.join(__dirname, 'public'))); 
var bodyParser = require('body-parser');
var urlencodedParser = bodyParser.urlencoded({ extended: true });

var db = require('mongodb').MongoClient;

db.connect("mongodb://localhost:27017/exampleDb");



app.get('/',function(req,res){
    var msg = 'Welcome to node Js';
    
    res.end(msg);
    res.sendFile(__dirname+'/template/index.html');
})
app.get('/users',function(req,res){
     //db.collection('tbl_employee');
     msg = {username : 'balsundar',email:'32deva@gmail.com'};
     res.end(JSON.stringify(msg)); //           
})


app.listen(8081); // Super PORT
