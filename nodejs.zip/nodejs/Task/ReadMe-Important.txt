i.  Install nodejs on your PC  => set nodejs configuration as per documentation

ii. Install nodemon on your PC 

iii.E:\project full path\node app.js [OR] E:\project full path\nodemon app.js => while run it will be run automatically every changes.

iv.Install CMD : E:\project full path\npm install express,cookie-parser,body-parser,angular-file-upload,multer,mysql, fs => whatever you need you can install using this cmd. 

v. File Upload in Angularjs :

	var file = $('#profile').prop('files')[0];
            var fd = new FormData();
            fd.append('profile', file);
            
            fd.append("data", JSON.stringify($scope.user));

$http.post(url,formData,
{ transformRequest: angular.identity,
             headers: {'Content-Type': undefined,'Process-Data': false}
         }

server.js

You have to JSON.Parse in node Js server side

vi. While return data use res.end(JSON.stringify(result)); on app.js
   
    Example :

    app.get('/users', function (req, res){
        db.query("select * from tbl_users",function (err,result){                 
                  res.end(JSON.stringify(result));            
         }); 
    });
